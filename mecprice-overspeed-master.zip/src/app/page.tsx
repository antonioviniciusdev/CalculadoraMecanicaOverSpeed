/* eslint-disable @next/next/no-img-element */
"use client"
import Link from "next/link"
import { useEffect, useState } from "react"
import { FiInfo } from "react-icons/fi"

const initialModState = {
  blindagem: 0,
  mod: 0,
  modQty: 0,
  xenonCompleto: 0,
  xenonCor: 0,
  neonCompleto: 0,
  neonCor: 0,
  reparo: 0,
  separados: {
    freio: 0,
    motor: 0,
    blindagem: 0,
    suspensao: 0,
    transmissao: 0,
    turbo: 0,
  },
}

export default function Home() {
  const [modValues, setModValues] = useState(initialModState)
  const [totalValue, setTotalPrice] = useState("R$ 0,00")
  const [totalValuePrice, setTotalPriceTotal] = useState(0)

  useEffect(() => {
    const {
      blindagem,
      mod,
      xenonCompleto,
      xenonCor,
      neonCompleto,
      neonCor,
      reparo,
      separados,
    } = modValues
    const valorTotal =
      blindagem +
      mod +
      xenonCompleto +
      xenonCor +
      neonCompleto +
      neonCor +
      reparo +
      separados.freio +
      separados.blindagem +
      separados.motor +
      separados.suspensao +
      separados.turbo +
      separados.transmissao
    const valorTotalFinal = valorTotal.toLocaleString("pt-br", {
      style: "currency",
      currency: "BRL",
    })

    setTotalPrice(valorTotalFinal)
    setTotalPriceTotal(valorTotal)
  }, [modValues])

  const allSeparadosZero = Object.values(modValues.separados).every(
    (value) => value === 0
  )

  const handleRemoveAll = () => {
    const updatedSeparados = {
      freio: 0,
      motor: 0,
      blindagem: 0,
      suspensao: 0,
      transmissao: 0,
      turbo: 0,
    }

    setModValues((prevState) => ({
      ...prevState,
      separados: updatedSeparados,
    }))
  }

  const handleMods = (value: number, cond: number) => {
    setModValues((prevModValues) => {
      const updatedModValues = { ...prevModValues }

      if (cond === 0 && updatedModValues.modQty > 0) {
        updatedModValues.mod -= value
        updatedModValues.modQty -= 1
      } else if (cond === 1) {
        updatedModValues.mod += value
        updatedModValues.modQty += 1
      } else if (cond === 2) {
        updatedModValues.mod = 0
        updatedModValues.modQty = 0
      }

      return updatedModValues
    })
  }

  const handleTotalPrice = () => {
    if (totalValue === "R$ 0,00") return

    setModValues(initialModState)
    setTotalPrice("R$ 0,00")
  }

  return (
    <>
      <main className="flex flex-col min-h-screen py-5 justify-center items-center md:justify-start md:items-start w-full px-5 md:px-36 lg:px-48">
        <div className="h-24 w-1/1 mb-5">
          <img src="/logo.png" className="h-full w-full" alt="overspeed" />
        </div>
        <div className="flex w-full flex-col md:flex-row gap-6">
          <div className="w-full relative bg-white h-auto shadow-sm ring-1 ring-gray-900/5 rounded-lg px-6">
            <div className="divide-y divide-gray-300/50">
              <div className="space-y-6 py-8 text-base leading-7 text-gray-600">
                <ul className="list-none gap-5 flex flex-col">
                  <li>
                    <div className="flex flex-col w-full">
                      <div className="flex flex-col gap-2">
                        <div className="flex w-full flex-col gap-3 items-start justify-between">
                          <p className="font-medium text-lg">
                            Melhorias separadas
                          </p>
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              disabled={modValues.separados.freio > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  separados: {
                                    ...prevState.separados,
                                    freio: 80000,
                                  },
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Freio R$80k
                            </button>
                            <button
                              disabled={modValues.separados.motor > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  separados: {
                                    ...prevState.separados,
                                    motor: 80000,
                                  },
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Motor R$80k
                            </button>
                            <button
                              disabled={modValues.separados.suspensao > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  separados: {
                                    ...prevState.separados,
                                    suspensao: 80000,
                                  },
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Suspensão R$80k
                            </button>
                            <button
                              disabled={modValues.separados.blindagem > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  separados: {
                                    ...prevState.separados,
                                    blindagem: 105000,
                                  },
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Blindagem R$105k
                            </button>
                            <button
                              disabled={modValues.separados.transmissao > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  separados: {
                                    ...prevState.separados,
                                    transmissao: 80000,
                                  },
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Transmissão R$80k
                            </button>
                            <button
                              disabled={modValues.separados.turbo > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  separados: {
                                    ...prevState.separados,
                                    turbo: 100000,
                                  },
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Turbo R$100k
                            </button>
                            <button
                              disabled={allSeparadosZero}
                              onClick={handleRemoveAll}
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              Remover Tudo
                            </button>
                          </div>
                        </div>
                        <div className="w-full flex items-baseline gap-2">
                          <FiInfo />{" "}
                          <p>
                            Modificações separadas, motor, blindagem, etc...
                          </p>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex flex-col w-full">
                      <div className="flex flex-col gap-2">
                        <div className="flex flex-col w-full gap-3 items-start justify-between">
                          <p className="font-medium text-lg">Modificação</p>
                          <div className="flex items-start justify-start md:items-center md:justify-between gap-2 flex-wrap">
                            <button
                              onClick={() => handleMods(20000, 1)}
                              className="py-1 px-3 text-sm hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              +1 | R$20K
                            </button>

                            <button
                              disabled={modValues.mod === 0}
                              onClick={() => handleMods(20000, 0)}
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              -1 | R$20K
                            </button>

                            <button
                              disabled={modValues.mod === 0}
                              onClick={() => handleMods(0, 2)}
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              Remover Tudo
                            </button>
                          </div>
                        </div>
                        <div className="w-full flex items-baseline justify-start gap-2">
                          <FiInfo />{" "}
                          <p>
                            Adicione ou remova a cada modificação, roda/cor/capo
                            etc...
                          </p>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex flex-col w-full">
                      <div className="flex flex-col gap-2">
                        <div className="flex w-full flex-col gap-3 items-start justify-between">
                          <p className="font-medium text-lg">Full-Tunning</p>
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              disabled={modValues.blindagem > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  blindagem: 525000,
                                }))
                              }
                              title="adicionar com blindagem"
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Blindagem | R$525K
                            </button>
                            <button
                              disabled={modValues.blindagem > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  blindagem: 450000,
                                }))
                              }
                              title="adicionar sem blindagem"
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Sem Blindagem | R$450K
                            </button>
                            <button
                              disabled={modValues.blindagem === 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  blindagem: 0,
                                }))
                              }
                              title="Remover blindagem"
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              Remover
                            </button>
                          </div>
                        </div>
                        <div className="w-full flex items-baseline gap-2">
                          <FiInfo />{" "}
                          <p>Tunagem completa no carro com ou sem blindagem!</p>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex flex-col w-full">
                      <div className="flex flex-col gap-2">
                        <div className="flex w-full flex-col gap-3 items-start justify-between">
                          <p className="font-medium text-lg">Reparo</p>
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              disabled={modValues.reparo > 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  reparo: 10000,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Adicionar | R$10K
                            </button>
                            <button
                              disabled={modValues.reparo === 0}
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  reparo: 0,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              Remover | -R$10K
                            </button>
                          </div>
                        </div>
                        <div className="w-full flex items-baseline gap-2">
                          <FiInfo /> <p>Reparo no carro dentro da mecânica.</p>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex flex-col w-full">
                      <div className="flex flex-col gap-2">
                        <div className="flex w-full flex-col gap-3 items-start justify-between">
                          <p className="font-medium text-lg">Xenons</p>
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              disabled={
                                modValues.xenonCor > 0 ||
                                modValues.xenonCompleto > 0
                              }
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  xenonCompleto: 40000,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Completo | R$40K
                            </button>
                            <button
                              disabled={
                                modValues.xenonCor > 0 ||
                                modValues.xenonCompleto > 0
                              }
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  xenonCor: 20000,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Apenas Cor | R$20K
                            </button>
                            <button
                              disabled={
                                !(
                                  modValues.xenonCompleto !== 0 ||
                                  modValues.xenonCor !== 0
                                )
                              }
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  xenonCompleto: 0,
                                  xenonCor: 0,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              Remover Tudo
                            </button>
                          </div>
                        </div>
                        <div className="w-full flex items-baseline gap-2">
                          <FiInfo />{" "}
                          <p>
                            Adicione um Xenon completo ao carro ou apenas 1 cor.
                          </p>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex flex-col w-full">
                      <div className="flex flex-col gap-2">
                        <div className="flex w-full flex-col gap-3 items-start justify-between">
                          <p className="font-medium text-lg">Neons</p>
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              disabled={
                                modValues.neonCompleto > 0 ||
                                modValues.neonCor > 0
                              }
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  neonCompleto: 100000,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Completo | R$100k
                            </button>
                            <button
                              disabled={
                                modValues.neonCompleto > 0 ||
                                modValues.neonCor > 0
                              }
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  neonCor: 20000,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 hover:bg-green-950 bg-green-700 rounded-md text-white font-medium"
                            >
                              Apenas cor | R$20k
                            </button>
                            <button
                              disabled={
                                !(
                                  modValues.neonCompleto !== 0 ||
                                  modValues.neonCor !== 0
                                )
                              }
                              onClick={() =>
                                setModValues((prevState) => ({
                                  ...prevState,
                                  neonCompleto: 0,
                                  neonCor: 0,
                                }))
                              }
                              className="py-1 px-3 text-sm disabled:opacity-40 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
                            >
                              Remover Tudo
                            </button>
                          </div>
                        </div>
                        <div className="w-full flex items-baseline gap-2">
                          <FiInfo />{" "}
                          <p>
                            Adicione um Neon completo ao carro ou apenas 1 cor.
                          </p>
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="w-full md:w-1/2 relative bg-white h-1/4 pb-8 shadow-sm ring-1 ring-gray-900/5 rounded-lg px-6">
            <div className="pt-8 text-base font-semibold leading-7">
              <p className="text-gray-900">PREÇO TOTAL</p>
              <h1 className="text-3xl md:text-4xl mt-5">{totalValue}</h1>

              <div className="mt-3 text-gray-600 font-normal px-4">
                <ul className="list-disc">
                  {modValues.modQty >= 1 && (
                    <li>
                      {modValues.modQty >= 2
                        ? `${modValues.modQty} Modificações`
                        : `${modValues.modQty} Modificação`}
                    </li>
                  )}
                  {modValues.blindagem === 525000 ? (
                    <li>Full-Tunning com Blindagem</li>
                  ) : modValues.blindagem === 450000 ? (
                    <li>Full-Tunning sem Blindagem</li>
                  ) : (
                    ""
                  )}
                  {modValues.xenonCompleto ? <li>Xenon completo</li> : ""}
                  {modValues.xenonCor ? <li>Xenon cor</li> : ""}
                  {modValues.neonCompleto ? <li>Neon completo</li> : ""}
                  {modValues.neonCor ? <li>Neon cor</li> : ""}
                  {modValues.reparo ? <li>Reparo na Mecânica</li> : ""}
                  {modValues.separados.blindagem ? (
                    <li>Melhoria Blindagem</li>
                  ) : (
                    ""
                  )}
                  {modValues.separados.turbo ? <li>Melhoria Turbo</li> : ""}
                  {modValues.separados.transmissao ? (
                    <li>Melhoria Transmissão</li>
                  ) : (
                    ""
                  )}
                  {modValues.separados.motor ? <li>Melhoria Motor</li> : ""}
                  {modValues.separados.freio ? <li>Melhoria Freio</li> : ""}
                  {modValues.separados.suspensao ? (
                    <li>Melhoria Suspensão</li>
                  ) : (
                    ""
                  )}
                </ul>
              </div>
            </div>
            <div className="mt-8">
              <button
                disabled={totalValuePrice === 0}
                onClick={handleTotalPrice}
                className="py-2 px-9 disabled:opacity-20 bg-red-600 hover:bg-red-900 rounded-md text-white font-medium"
              >
                Zerar Total
              </button>
            </div>
            <div className="pt-8 text-base font-semibold leading-7">
              <p className="text-gray-900">OverSpeed - Nobre</p>
              <p>
                <Link
                  passHref
                  target="_blank"
                  href="https://discord.gg/ndSP7pjmUt"
                  className="text-sky-500 hover:text-sky-600"
                >
                  Discord Acessar &rarr;
                </Link>
              </p>
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
